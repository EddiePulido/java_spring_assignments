
public class FBTest{
    public static void main(String[] args){
        FizzBuzz fizz = new FizzBuzz();

        for(int i=0;i <= 20;i++){
            System.out.println(fizz.fizzBuzz(i));
        }
    }
}
