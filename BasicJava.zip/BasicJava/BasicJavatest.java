import java.util.ArrayList;
import java.util.Arrays;

public class BasicJavaTest{
    public static void main(String[] args){
        BasicJava jav = new BasicJava();

        // jav.print();

        int[] arr = {1,3,5,7,9,13};

        ArrayList<Integer> nums = new ArrayList<Integer>();
        nums.add(1);
        nums.add(4);
        nums.add(-4);
        nums.add(5);
        nums.add(-6);
        nums.add(43);

        // jav.printEach(arr);

        // System.out.println(jav.findMax(arr));

        // System.out.println(jav.average(arr));

        // System.out.println(jav.arrayOdd());

        // System.out.println(jav.greater(arr,6));

        // System.out.println(Arrays.toString(jav.squareValues(arr)));

        // System.out.println(Arrays.toString(jav.minMaxAvg(arr)));

        // System.out.println(jav.removeNeg(nums));


        System.out.println(Arrays.toString(jav.shift(arr)));






    }
}
